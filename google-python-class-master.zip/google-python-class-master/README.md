# google-python-class
[Mirror] Google's Python Class Exercises

This repository aims to port google's exercises package to python3.x
https://developers.google.com/edu/python/
